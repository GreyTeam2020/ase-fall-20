from myservice.views.home import home
from myservice.views.calc import calc

blueprints = [home,calc]
